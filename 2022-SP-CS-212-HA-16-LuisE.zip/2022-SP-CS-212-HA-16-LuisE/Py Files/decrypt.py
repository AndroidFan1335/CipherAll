class Decrypt(Encrypt):

    """This is the Decrypt Class.  This class will be resposible for decrypting ciphertext if given the correct decryption key. 
Similar to the Encrypt Class, much of its functionaliy will be inherited from the Manageer Class. """

    def __init__(self, SharedKey, textFieldCipher):
        '''initalization method'''
        super().__init__(SharedKey,textFieldCipher)
        plainText = ""


    def SED(ciphertext, password):
        charset = 'ISO-8859-1'
        def encoder(input):
            x = input.encode(charset)
            return x


        cipherencoded = encoder(ciphertext)
        k = pyDes.des(password, pyDes.CBC, "\0\0\0\0\0\0\0\0", pad = None, padmode = pyDes.PAD_PKCS5)
        r = k.decrypt(cipherencoded)
        #plaintext = r.decode(charset)
        return r