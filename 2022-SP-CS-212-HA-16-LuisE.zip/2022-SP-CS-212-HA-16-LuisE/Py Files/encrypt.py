class Encrypt(Manager):

    """This is the Encrypt Class. This class will be responsible for encrypting any given plaintext and spitting out 
a cipher text along with a shared key, if one is needed. Much of its output will be dependant on the information
provided from the UserInput class, so it will inherit much of its methods and data.  Currently having issues with 
imple)menting PyDes as this implementation encrypts strings as bytes (which makes sense from a security standpoint) which makes
it difficult to implement a definite encrypt function.  Currently replaced with encryption functions used in a previous assignment 
as a placeholder in order to make progress on the GUI. Blocks of code that utilized the PyDes implementation blocked out pending
further review. """
    




    def DES(plaintext, password):
        charset = 'ISO-8859-1'
        def decode(input):
            x = input.decode(charset)
            return x
        def encoder(input):
            x = input.encode(charset)
            return x

        plainencoded = encoder(plaintext)
        k = pyDes.des(password, pyDes.CBC, "\0\0\0\0\0\0\0\0", pad = None, padmode = pyDes.PAD_PKCS5)
        r =k.encrypt(plainencoded)
        #ciphertext = r.decode(charset)
        new = decode(r)
        return new


    def strGen():         
        ''' This is a temporary pseudo-random shared key generator.  This method is responsible for creating a fairly secure
            shared key that can be used with any given plaintext in an encryption algorithm.  Will be updated with a more hardened generator
            as the project progresses.  Function definition source code obtained in part via: “How to Generate a Random String in Python.” 
            Educative, https://www.educative.io/edpresso/how-to-generate-a-random-string-in-python. ''' 
        alphabet = string.ascii_lowercase + "0123456789"
        randEnd = 8
        newString = ''.join(random.choice(alphabet) for i in
                            range(0, randEnd))
        return newString