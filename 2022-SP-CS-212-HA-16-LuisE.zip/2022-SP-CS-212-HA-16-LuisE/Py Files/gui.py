class GUI(Manager):

    
    '''This is the GUI Class. This class is mostly responsible for facilitating the collection 
of data from the user in a manner that the program as a whole can utilize and manipulate
said data. At the moment, the class currently has the tkinter schematics for the 'Encrypt' portion 
of the program, and will be expanded to also include the 'Decrypt' portion once all classes 
can communicate properly with eachother (which will take some debugging on my end) '''
   

    def __init__(self, master):
        self.master = master
        master.geometry('1600x1600')
        master.title("CipherAll")
        #photo = PhotoImage(file = 'sample icon.png')
        #master.iconphoto(False, photo)

        menubar = Menu(master)
        helpmenu = Menu(menubar, tearoff = 0)
        helpmenu.add_command(label = "What is this?", command = self.helpWindow)
        helpmenu.add_command(label = 'How to use?', command = self.howToUse)
        menubar.add_cascade(label = 'Help', menu = helpmenu)
        master.config(menu = menubar)



        ###Elements from the Encrypt portion of the GUI###


        self.labelEncrypt = tk.Label(master, text="Enter the Plaintext you want encrypted here:")
        self.labelEncrypt.grid(row=0, column=0)

        self.entryEncrypt = tk.Entry(master)
        self.entryEncrypt.grid(row=1, column=0)

        self.doneButton = tk.Button(master, text="Done!", command=self.doneClick)
        self.doneButton.grid(row=2, column=0)

        self.nullSpaceVert = tk.Label(master, text="\n")
        self.nullSpaceVert.grid(row=3, column=0)

        self.labelSharedKey = tk.Label(master, text="Enter a Password Here | Under 8 Characters:")
        self.labelSharedKey.grid(row=4, column=0)

        self.entrySharedKey = tk.Entry(master)
        self.entrySharedKey.grid(row=5, column=0)

        self.doneButton2 = tk.Button(master, text="Done!", command=self.doneClick2)
        self.doneButton2.grid(row=6, column=0)

        self.randButton = tk.Button(master, text="Make me One!", command=self.randFunc)
        self.randButton.grid(row=7, column=0)

        self.nullSpaceVert1 = tk.Label(master, text="\n")
        self.nullSpaceVert1.grid(row=8, column=0)

        self.var = tk.StringVar()
        self.var2 = tk.StringVar()
        self.radioLabel = tk.Label(master, text="Choose your Encryption Method Below:")
        self.radioLabel.grid(row=9, column=0)
        self.r1 = tk.Radiobutton(master, text="DES", variable=self.var, value="DES", command=self.radioSelection)
        self.r1.grid(row=10, column=0)
        self.r2 = tk.Radiobutton(master, text="AES", variable=self.var, value="AES", command=self.radioSelection, state = tk.DISABLED)
        self.r2.grid(row=11, column=0)
        self.r3 = tk.Radiobutton(master, text="BlowFish", variable=self.var, value="BlowFish", command=self.radioSelection, state = tk.DISABLED)
        self.r3.grid(row=12, column=0)

        self.enterButton = tk.Button(master, text = "Encrypt my Text!", command = self.scramble)
        self.enterButton.grid(row = 13, column = 0)

        self.op1 = tk.Label(master, bg='white', width=40, text='More Encryption Algorithms Coming Soon!')
        self.op1.grid(row=14, column=0)
        self.op2 = tk.Text(master, bg = 'white', width = 70, height = 2)
        self.op2.grid(row = 17, column = 0)
        self.nullSpaceVert2 = tk.Label(master, text="\n")
        self.nullSpaceVert2.grid(row=15, column=0)
        self.labelOut = tk.Label(master, text='Result: ')
        self.labelOut.grid(row=16, column=0)

        ##Elements of the Decrypt portion of the GUI### 

        self.labelEncryptD = tk.Label(master, text="Enter the CipherText you want Decrypted here")
        self.labelEncryptD.grid(row=0, column=1)

        self.entryEncryptD = tk.Entry(master)
        self.entryEncryptD.grid(row=1, column=1)

        self.doneButtonD = tk.Button(master, text="Done!", command=self.doneClickD)
        self.doneButtonD.grid(row=2, column=1)

        self.nullSpaceVertD = tk.Label(master, text="\n")
        self.nullSpaceVertD.grid(row=3, column=1)

        self.labelSharedKeyD = tk.Label(master, text="Enter the correct Password Here | Under 8 Characters")
        self.labelSharedKeyD.grid(row=4, column=1)

        self.entrySharedKeyD = tk.Entry(master)
        self.entrySharedKeyD.grid(row=5, column=1)

        self.doneButton2D = tk.Button(master, text="Done!", command=self.doneClick2D)
        self.doneButton2D.grid(row=6, column=1)

        #self.randButtonD = tk.Button(master, text="Make me One!", command=self.randFuncD)
        #self.randButtonD.grid(row=7, column=1)

        self.nullSpaceVert1D = tk.Label(master, text="\n")
        self.nullSpaceVert1D.grid(row=8, column=1)

        self.varD = tk.StringVar()
        self.var2D = tk.StringVar()
        self.radioLabelD = tk.Label(master, text="Choose your Encryption Method")
        self.radioLabelD.grid(row=9, column=1)
        self.r1D = tk.Radiobutton(master, text="DES", variable=self.var, value="DES", command=self.radioSelectionD)
        self.r1D.grid(row=10, column=1)
        self.r2D = tk.Radiobutton(master, text="AES", variable=self.var, value="AES", command=self.radioSelectionD, state = tk.DISABLED)
        self.r2D.grid(row=11, column=1)
        self.r3D = tk.Radiobutton(master, text="TwoFish", variable=self.var, value="TwoFish",
                                 command=self.radioSelectionD, state = tk.DISABLED)
        self.r3D.grid(row=12, column=1)

        self.enterButtonD = tk.Button(master, text = "Decrypt my Text!", command = self.scrambleD)
        self.enterButtonD.grid(row = 13, column = 1)

        self.op1D = tk.Label(master, bg='white', width=40, text='More Encryption Algorithms Coming Soon!')
        self.op1D.grid(row=14, column=1)
        self.op2D = tk.Text(master, bg = 'white', width = 70, height = 2)
        self.op2D.grid(row = 17, column = 1)
        self.nullSpaceVert2D = tk.Label(master, text="\n")
        self.nullSpaceVert2D.grid(row=15, column=1)
        self.labelOutD = tk.Label(master, text='Result: ')
        self.labelOutD.grid(row=16, column=1)

        ##Encrypt portion functions###


    def doneClick(self):
        """This method is responsible for returning whatever text was placed inside of the "entryEncrypt" 
        text box.  this method also includes a print function that outputs the same content for future debugging purposes"""
        self.finalPlain = self.entryEncrypt.get()
        ##print("|DEBUGGING| Output: \n" + self.finalPlain)
        if (len(str(self.finalPlain)) == 0):
            messagebox.showinfo("Error", "Please Insert valid Plaintext.")
        else:  
            Manager.getPlainTxt(self.finalPlain)


    def doneClick2(self):
        '''Similar to the method above, this method is responsible for returning the contents of the 'entrySharedKey' text
        box.  It also prints the same data for future debugging.   May combine with the above function to avoid creating
        repetitive methods. '''
        self.finalText = self.entrySharedKey.get()
        
        if (len(str(self.finalText)) > 8):
            self.entrySharedKey.delete(0,END)
            messagebox.showinfo("Error", "Shared Key over expected size limit (8 characters).")
        elif (len(str(self.finalText)) < 8):
            self.entrySharedKey.delete(0,END)
            messagebox.showinfo("Error", "Shared Key under expected size limit (8 characters).")
        else:
            Manager.getSharedKey(self.finalText)


    def helpWindow(self):
        top= Toplevel(self.master)
        top.geometry("850x350")
        top.title("What is this?")
        
        Label(top, text = "Hello! Welcome to CipherAll!\nThis application was created as a way to demonstrate how symmetric encryption algorithms function.\n Encryption is all over our technological world.  Many forms of instant messaging online, such as \nSnapchat, Telegram, WhatsApp, utitlize encryption to protect the messages you send from being read by anyone else other \nthan yourself and your message recipient. \n\n").pack()
        Label(top, text = 'This application demonstrates, in a very primitive way, how messages such as those sent through the applications above\n are encrypted over the air.').pack()
        Label(top, text = 'Although this application does encrypt plaintext into ciphertext using industry standards,\n\n[!!!THIS APPLICATION SHOULD NOT BE USED TO ENCRYPT SENSITIVE INFORMATION!!!]\n\nThis application is only meant to serve as a demonstration tool.').pack()


    def howToUse(self):
        top= Toplevel(self.master)
        top.geometry("650x500")
        top.title("How to Use")
        #Create a label in Toplevel window
        Label(top, text = 'To Encrypt:').pack()
        Label(top, text= "1. Begin by entering any text you would like to encrypt in the first entry box and click 'Done!'. ").pack()
        Label(top, text= "2. Enter a unique 8 character password in the second entry box and click \"Done!\".\n If you have trouble thinking of a unique password, click on \"Make me One!\" to\n have one randomly generated for you.").pack()
        Label(top, text='3. Choose your desired Encryption Method by clicking on any of the radio buttons listed. ').pack()
        Label(top, text= '    DES: works by taking a plaintext input and breaking it into smaller chunks\n(64-bit blocks) to encrypt it using a cryptographic key. Basically, it takes \nyour readable message and, block by block, converts it into unreadable\ngibberish that can only be decrypted by the decryption key holder. \n-InfoSec Insights').pack()
        Label(top, text= '4. Click on "Encrypt my Text!" to recieve your encrypted text.\n Copy the text by highlighting the text and holding the \'CTRL\' and \'C\' Keys.\nTo paste the text, hold the \'CTRL\' and \'V\' keys.').pack()

        Label(top, text = '\nTo Decrypt:').pack()
        Label(top, text= "1. Begin by entering the ciphertext provided to you and click 'Done!'. ").pack()
        Label(top, text= "2. Enter the 8 character password associated with the ciphertext proved above.\nIf the incorrect password is provided, the decrypted text may be unreadable.").pack()
        Label(top, text='3. Choose the encryption method associated with the ciphertext above. ').pack()
        Label(top, text= '4. Click on "Decrypt my Text!" to recieve your Decrypted text. \n Copy the text by highlighting the text and holding the \'CTRL\' and \'C\' Keys.\nTo paste the text, hold the \'CTRL\' and \'V\' keys.').pack()



    def randFunc(self):
        '''this method is responsible for providing a pseudo-randomly generated shared ky for the user 
        to use in encrypting their plaintext.  at the moment it has a pre-defined key as the 'Encrypt' class 
        has a function just for this purpose, but still need to make the classess work with one another.  This method 
        also erases any text inside of the text box and auto fills it with the contents of the auto-gen key'''
        self.key = Encrypt.strGen()
        self.entrySharedKey.delete(0,tk.END)
        self.entrySharedKey.insert(0, self.key)


    def radioSelection(self):
        '''this method is responsible for displaying to the user what encryption algorithm they have selected, 
        and returning that information to the other classes.  Similar to other methods above, a debugging print
        is also included. Mostly a proof of concept as none of the radio buttons affect the encryption/decryption 
        as of yet. '''
        self.op1.config(text="You Have Selected: " + self.var.get())
        print("|DEBUGGING| Reported Algorithm: " + self.var.get())
        return self.var.get()

    def scramble(self):
            self.op2.configure(state = 'normal')
            Manager.verify(self.finalPlain, self.finalText)
            finalEncrypt = Encrypt.DES(self.finalPlain, self.finalText)
            self.op2.insert(1.0, str(finalEncrypt))
            #self.op2.configure(state = 'disabled')

        ##print("|DEBUGGING| Reported Algorithm: " + self.var.get())
        #print (finalEncrypt)
        #return finalEncrypt

        ###Decrypt Portion Functions 

    def doneClickD(self):
        """Duplicate method variant for the Decrypt Method and its respective appropriate changes"""
        self.finalPlainD = self.entryEncryptD.get()
        if (len(str(self.finalPlainD)) == 0):
            messagebox.showinfo("Error", "Please Insert valid Ciphertext.")
        else:  
            Manager.getPlainTxt(self.finalPlainD)


    def doneClick2D(self):
        """Duplicate method variant for the Decrypt Method and its respective appropriate changes"""
        self.finalTextD = self.entrySharedKeyD.get()
        if (len(str(self.finalTextD)) > 8):
            self.entrySharedKey.delete(0,END)
            messagebox.showinfo("Error", "Shared Key over expected size limit (8 characters).")
        elif (len(str(self.finalTextD)) < 8):
            self.entrySharedKey.delete(0,END)
            messagebox.showinfo("Error", "Shared Key under expected size limit (8 characters).")
        else:
            Manager.getSharedKey(self.finalTextD)
        


    def randFuncD(self):
        """Duplicate method variant for the Decrypt Method and its respective appropriate changes"""
        self.key = Encrypt.strGen()
        self.entrySharedKey.delete(0,tk.END)
        self.entrySharedKey.insert(0, self.key)


    def radioSelectionD(self):
        """Duplicate method variant for the Decrypt Method and its respective appropriate changes"""
        self.op1D.config(text="You Have Selected: " + self.varD.get())
        print("|DEBUGGING| Reported Algorithm: " + self.varD.get())
        return self.varD.get()

    def scrambleD(self):
        """Duplicate method variant for the Decrypt Method and its respective appropriate changes"""
        self.op2D.configure(state = 'normal')
        Manager.verify(self.finalPlainD, self.finalTextD)
        finalEncryptD = Decrypt.SED(self.finalPlainD, self.finalTextD)
        self.op2D.insert(1.0, str(finalEncryptD))
        #self.op2D.configure(state = 'disabled')

        ##print("|DEBUGGING| Reported Algorithm: " + self.var.get())
        #print (finalEncrypt)
        #return finalEncrypt